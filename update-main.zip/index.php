<?php
include ("inc_head.php");
?>


<div class="container">
<font color="#000000">
<div class="col-lg-12  wow zoomIn animated" style="visibility: visible; animation-name: zoomIn;animation-delay: 1.0s;"> 
<a href="<?php echo $nook;?>" class="btn btn-outline-success rounded-pill"><i class="fa fa-comments-o" aria-hidden="true"></i> NK PRO</a> 
</div>
</div>
<p>
<div class="container">
<font color="#000000">
<div class="col-lg-12  wow zoomIn animated" style="visibility: visible; animation-name: zoomIn;animation-delay: 1.0s;"> 
<a href="<?php echo $okay;?>" class="btn btn-outline-info rounded-pill"><i class="fa fa-comments-o" aria-hidden="true"></i> no app</a> 
</div>
</div>
<center>          
<meta http-equiv="REFRESH" content="10;url=https://github.com/Nookerzi1992/updata-Auto/blob/main/NK%20PRO.apk"> 
 </head> 
 
<p>
<div class="container">
	<marquee behavior="alternate"><marquee width="290"><B><FONT COLOR='#990000' size='2'> Download App กรุณารอ 10 วินาที หรือกดโหลดเลือกแอปด้านบน รองรับ ซิมการ์ด ทรู ดีแทค</B></FONT></marquee></marquee>
<div class="card text-center mt-1 mb-3">
<font color="#000000"><B>©Copyright 2023 | NOOKER Free VPN™</B></font></center>



